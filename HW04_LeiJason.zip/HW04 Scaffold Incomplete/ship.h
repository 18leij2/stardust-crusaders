
//{{BLOCK(ship)

//======================================================================
//
//	ship, 36x36@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 1296 = 1808
//
//	Time-stamp: 2023-02-28, 12:58:05
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SHIP_H
#define GRIT_SHIP_H

#define shipBitmapLen 1296
extern const unsigned short shipBitmap[648];

#define shipPalLen 512
extern const unsigned short shipPal[256];

#endif // GRIT_SHIP_H

//}}BLOCK(ship)
